<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Products Controller
 *
 * @property \App\Model\Table\ProductsTable $Products
 *
 * @method \App\Model\Entity\Product[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ProductsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $products = $this->paginate($this->Products);

        $this->set(compact('products'));
    }

    /**
     * View method
     *
     * @param string|null $id Product id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $product = $this->Products->get($id, [
            'contain' => [],
        ]);

        $this->set('product', $product);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $product = $this->Products->newEntity();
        if ($this->request->is('post')) {
            //upload image code.
            //pr($this->request->data()); die
            $allProduct = $this->request->data();
            if(!empty($this->request->data['image']['name'])){
                $fileName = $this->request->data['image']['name'];
                $uploadPath = 'uploads/productimages/';
                $uploadFile = $uploadPath.$fileName;
                if(move_uploaded_file($this->request->data['image']['tmp_name'],$uploadFile)){
                    $uploadData = $this->Products->newEntity();
                    $uploadData->name = isset($allProduct['name']) ?  $allProduct['name'] : '';
                    $uploadData->image = $fileName;
                    $uploadData->price = isset($allProduct['price']) ?  $allProduct['price'] : 0;
                    $uploadData->description = isset($allProduct['description']) ?  $allProduct['description'] : '';
                    $uploadData->quantity = isset($allProduct['quantity']) ?  $allProduct['quantity'] : 0;
                    $uploadData->status = isset($allProduct['status']) ?  $allProduct['status'] : 1;
                    if ($this->Products->save($uploadData)) {
                         $this->Flash->success(__('The product has been saved.'));
                            return $this->redirect(['action' => 'index']);
                    }else{
                        $this->Flash->error(__('The product could not be saved. Please, try again.'));
                    }
                }else{
                    $this->Flash->error(__('Unable to upload file, please try again.'));
                }
            }else{
                $this->Flash->error(__('Please choose a file to upload.'));
            } //end upload image code.
        }
        $this->set(compact('product'));
    }

    public function order()
    {
        $this->Flash->success(__('The order has been add to cart.'));
        return $this->redirect(['controller' => 'products', 'action' => 'index']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Product id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $product = $this->Products->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $product = $this->Products->patchEntity($product, $this->request->getData());
            if ($this->Products->save($product)) {
                $this->Flash->success(__('The product has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The product could not be saved. Please, try again.'));
        }
        $this->set(compact('product'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Product id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $product = $this->Products->get($id);
        if ($this->Products->delete($product)) {
            $this->Flash->success(__('The product has been deleted.'));
        } else {
            $this->Flash->error(__('The product could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
